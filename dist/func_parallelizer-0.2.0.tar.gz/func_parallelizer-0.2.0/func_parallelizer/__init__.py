from .func_parallelizer import parallel_runner, all_cores
